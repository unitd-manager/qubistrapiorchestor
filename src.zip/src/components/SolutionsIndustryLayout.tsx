import { stripHtml } from "@/lib/strapi";

interface IndustryCard {
  title?: string;
  description?: string;
  icon?: string;
}

interface SolutionsIndustryLayoutProps {
  main_title?: string;
  description?: string;
  industry_cards?: IndustryCard[];
  class_name?: string;
}

/** Industry segment cards grid, used on the Solutions > Industries page. */
const SolutionsIndustryLayout = ({
  main_title,
  description,
  industry_cards,
  class_name,
}: SolutionsIndustryLayoutProps) => {
  const cards = industry_cards ?? [];

  return (
    <section className={`py-12 lg:py-16 bg-background ${class_name ?? ""}`}>
      <div className="container mx-auto px-4 lg:px-8">
        {main_title && (
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground text-center max-w-3xl mx-auto">
            {main_title}
          </h2>
        )}
        {description && (
          <div
            className="mt-6 text-lg text-muted-foreground text-center max-w-2xl mx-auto"
            dangerouslySetInnerHTML={{ __html: description }}
          />
        )}
        {cards.length > 0 && (
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            {cards.map((card, i) => (
              <div
                key={`${card.title ?? "industry"}-${i}`}
                className="p-8 rounded-2xl bg-surface-elevated border border-border"
              >
                {card.title && (
                  <h3 className="text-xl font-semibold text-foreground">{card.title}</h3>
                )}
                {card.description && (
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                    {stripHtml(card.description)}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default SolutionsIndustryLayout;